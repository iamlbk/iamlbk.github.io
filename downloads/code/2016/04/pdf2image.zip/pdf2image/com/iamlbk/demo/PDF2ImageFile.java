/*
 * Copyright 2016 LBK
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.iamlbk.demo;

import java.io.*;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.util.PDFImageWriter;

public class PDF2ImageFile {

	private static final String BASE_PATH = "F:\\java\\";

	public static void main(String[] args) throws IOException {
		File file = new File(BASE_PATH + "test.pdf");
		PDDocument doc = PDDocument.load(file);
		PDFImageWriter imageWriter = new PDFImageWriter();

		int pageCount = doc.getNumberOfPages();
		for (int i = 1; i <= pageCount; i++) {
			// 将第 i 到 i 页(也就是第i页)转换成图片, 并存到文件中
			imageWriter.writeImage(doc, "jpg", null, i, i, BASE_PATH + file.getName());
		}
	}

}
