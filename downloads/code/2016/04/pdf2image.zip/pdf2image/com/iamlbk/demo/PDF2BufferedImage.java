/*
 * Copyright 2016 LBK
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.iamlbk.demo;

import java.awt.image.BufferedImage;
import java.io.*;
import java.util.List;

import javax.imageio.ImageIO;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;

public class PDF2BufferedImage {

	private static final String BASE_PATH = "F:\\java\\";

	public static void main(String[] args) throws IOException {
		File file = new File(BASE_PATH + "test.pdf");
		PDDocument doc = PDDocument.load(file);
		List<?> pages = doc.getDocumentCatalog().getAllPages();

		for (int i = 0; i < pages.size(); i++) {
			PDPage page = (PDPage) pages.get(i); // 获取第i页
			BufferedImage image = page.convertToImage();

			// 输出到文件中
			String outPath = BASE_PATH + file.getName() + i + ".gif";
			try (FileOutputStream out = new FileOutputStream(outPath)) {
				ImageIO.write(image, "gif", out);
			}
		}
	}

}
