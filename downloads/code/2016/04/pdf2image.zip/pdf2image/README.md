﻿本程序是博客:《[pdf转图片(java语言实现)][blog url]》的示例程序.
博客地址: http://www.iamlbk.com/blog/20160424/java-pdf-to-image/

如果需要使用本程序，请注明出处.

[blog url]: http://www.iamlbk.com/blog/20160424/java-pdf-to-image/
