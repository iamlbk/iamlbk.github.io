/*
 * Copyright 2016 LBK
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package git.lbk.ratelimit;

import java.util.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 每日发送次数限制.
 */
public class DailyCountFilter implements SmsFilter {
	private static final Logger logger = LoggerFactory.getLogger(DailyCountFilter.class);

	private static final String KEY_PREFIX = "rate.daily.limiting:";

	private static final int SECOND_OF_DAY = 60 * 60 * 24;

	private int ipDailyMaxSendCount;
	private int mobileDailyMaxSendCount;
	private RateLimit rateLimit;

	public void setIpDailyMaxSendCount(int ipDailyMaxSendCount) {
		this.ipDailyMaxSendCount = ipDailyMaxSendCount;
	}

	public void setMobileDailyMaxSendCount(int mobileDailyMaxSendCount) {
		this.mobileDailyMaxSendCount = mobileDailyMaxSendCount;
	}

	public void setRateLimit(RateLimit rateLimit) {
		this.rateLimit = rateLimit;
	}

	@Override
	public void init() {}

	@Override
	public void filter(Sms sms) throws DailySendMuchException {
		if(rateLimit.isExceedRate(KEY_PREFIX+sms.getMobile(), SECOND_OF_DAY, mobileDailyMaxSendCount)
				|| rateLimit.isExceedRate(KEY_PREFIX+sms.getIp(), SECOND_OF_DAY, ipDailyMaxSendCount)){
			throw new DailySendMuchException("发送短信过于频繁");
		}
		// 记录日志, 用于日后分析
		logger.info(sms.toString());
	}

	@Override
	public void destroy() {}

}
