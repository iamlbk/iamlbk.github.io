﻿本程序是博客:《[发送短信--使用Redis限制发送频率和日发送次数][blog url]》的示例程序.
博客地址: http://www.iamlbk.com/blog/20160302/sms-java-code-with-redis/

如果需要使用本程序，请注明出处.

[blog url]: http://www.iamlbk.com/blog/20160302/sms-java-code-with-redis/
