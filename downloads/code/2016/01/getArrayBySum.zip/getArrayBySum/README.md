﻿本程序是博客:《[从N个数中取M个和为指定值的数][get-collection-by-sum]》的示例程序.
博客地址: http://www.iamlbk.com/blog/20160129/get-collection-by-sum/
如果需要使用本程序， 请注明出处.

- Data.java 包含测试数据
- ArraySum.java 穷举法代码
- ArraySum1.java 从ArraySum修改而来, 改进代码
- ArraySum2.java 采用分治法, 计算结果

[get-collection-by-sum]: http://www.iamlbk.com/blog/20160129/get-collection-by-sum/
