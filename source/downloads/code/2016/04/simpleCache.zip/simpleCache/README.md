﻿本程序是博客:《[简易缓存实现(java语言版)][blog url]》的示例程序.
博客地址: http://www.iamlbk.com/blog/20160402/java-simple-cache/

如果需要使用本程序，请注明出处.

[blog url]: http://www.iamlbk.com/blog/20160402/java-simple-cache/
