/*
 * Copyright 2015 LBK
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package git.lbk.entity;

import java.io.Serializable;
import java.util.*;

public class SmsEntity implements Serializable{

	private static final long serialVersionUID = -38794093210096359L;

	/**
	 * 注册类型
	 */
	public static final Integer REGISTER_TYPE = 0;

	private Integer id;
	private String mobile;
	private String ip;
	private Integer type;
	private Date time;
	private String captcha;

	public SmsEntity() {
		time = new Date();
	}

	public SmsEntity(String mobile, String ip, Integer type) {
		this();
		this.mobile = mobile;
		this.ip = ip;
		this.type = type;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String identity) {
		this.ip = identity;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public Date getTime() {
		return time;
	}

	public void setTime(Date time) {
		this.time = time;
	}

	public String getCaptcha() {
		return captcha;
	}

	public void setCaptcha(String captcha) {
		this.captcha = captcha;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((captcha == null) ? 0 : captcha.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((ip == null) ? 0 : ip.hashCode());
		result = prime * result + ((mobile == null) ? 0 : mobile.hashCode());
		result = prime * result + ((time == null) ? 0 : time.hashCode());
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SmsEntity other = (SmsEntity) obj;
		if (captcha == null) {
			if (other.captcha != null)
				return false;
		}
		else if (!captcha.equals(other.captcha))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		}
		else if (!id.equals(other.id))
			return false;
		if (ip == null) {
			if (other.ip != null)
				return false;
		}
		else if (!ip.equals(other.ip))
			return false;
		if (mobile == null) {
			if (other.mobile != null)
				return false;
		}
		else if (!mobile.equals(other.mobile))
			return false;
		if (time == null) {
			if (other.time != null)
				return false;
		}
		else if (!time.equals(other.time))
			return false;
		if (type == null) {
			if (other.type != null)
				return false;
		}
		else if (!type.equals(other.type))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "SmsEntity{" +
				"id=" + id +
				", mobile='" + mobile + '\'' +
				", ip='" + ip + '\'' +
				", type=" + type +
				", time=" + time +
				", captcha='" + captcha + '\'' +
				'}';
	}
}
