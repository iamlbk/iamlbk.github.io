/*
 * Copyright 2016 LBK
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package git.lbk.sms;

import java.util.Date;

import org.quartz.*;
import org.quartz.impl.StdSchedulerFactory;

import git.lbk.dao.SmsDao;
import git.lbk.entity.SmsEntity;

public class DailyCountFilter implements SmsFilter {

	private int ipDailyMaxSendCount;
	private int mobileDailyMaxSendCount;
	private SmsDao smsDao;
	private Scheduler sched;

	public DailyCountFilter(int ipDailyMaxSendCount, int mobileDailyMaxSendCount, SmsDao smsDao) {
		this.ipDailyMaxSendCount = ipDailyMaxSendCount;
		this.mobileDailyMaxSendCount = mobileDailyMaxSendCount;
		this.smsDao = smsDao;
	}

	public void setIpDailyMaxSendCount(int ipDailyMaxSendCount) {
		this.ipDailyMaxSendCount = ipDailyMaxSendCount;
	}

	public void setMobileDailyMaxSendCount(int mobileDailyMaxSendCount) {
		this.mobileDailyMaxSendCount = mobileDailyMaxSendCount;
	}

	public void setSmsDao(SmsDao smsDao) {
		this.smsDao = smsDao;
	}

	@Override
	public void init() throws SchedulerException {
		smsDao.createTable(0);
		smsDao.createTable(1);
		
		SchedulerFactory sf = new StdSchedulerFactory();
		sched = sf.getScheduler();	// 创建Quartz容器
		
		JobDataMap jobDataMap = new JobDataMap();
		jobDataMap.put("smsDao", smsDao);	// 创建运行任务时需要使用的数据map
		JobDetail job = JobBuilder.newJob(CreateSmsTableJob.class).usingJobData(jobDataMap)
				.withIdentity("create sms table job").build();	// 创建job对象, 该对象执行实际的任务

		CronTrigger trigger = TriggerBuilder.newTrigger()
				.withIdentity("create sms table trigger")
				.withSchedule(CronScheduleBuilder.cronSchedule("0 0 2 20 * ?"))	// 每月的20号2点
				.build();	// 创建trigger对象, 该对象用来描述触发执行job的时间规则

		sched.scheduleJob(job, trigger);	// 注册任务和触发规则
		sched.start();	// 启动调度
	}

	@Override
	public boolean filter(SmsEntity smsEntity) {
		if (smsDao.getMobileCount(smsEntity.getMobile()) >= mobileDailyMaxSendCount) {
			return false;
		}
		if (smsDao.getIPCount(smsEntity.getIp()) >= ipDailyMaxSendCount) {
			return false;
		}
		smsDao.saveEntity(smsEntity);
		return true;
	}

	@Override
	public void destroy() {
		try {
			sched.shutdown();
		}
		catch (SchedulerException e) {}
	}

	public static class CreateSmsTableJob implements Job {

		@Override
		public void execute(JobExecutionContext context) throws JobExecutionException {
			JobDataMap dataMap = context.getJobDetail().getJobDataMap();
			SmsDao smsDao = (SmsDao) dataMap.get("smsDao");
			smsDao.createTable(1);
			smsDao.createTable(2);
		}

	}

}
