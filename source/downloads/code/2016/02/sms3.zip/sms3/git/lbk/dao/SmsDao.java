﻿/*
 * Copyright 2015 LBK
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package git.lbk.dao;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import git.lbk.entity.SmsEntity;

public class SmsDao {

	/**
	 * 创建新的日志表
	 *
	 * @param monthExcursion 偏移的月数
	 */
	public void createTable(int monthExcursion){
		String sql = "CREATE TABLE IF NOT EXISTS " + getTableName(monthExcursion) + " LIKE sms";
		System.out.println("createTable: monthExcursion:"+monthExcursion);
	}

	/**
	 * 保存SmsEntity实体对象
	 */
	public void saveEntity(SmsEntity smsEntity){
		String sql = "INSERT INTO " + getNowTableName() + "(mobile, ip, type) VALUES(?, ?, ?)";
		System.out.println("saveSms, smsEntity:" + smsEntity);
	}

	/**
	 * 获得指定手机号今天请求发送短信的次数
	 *
	 * @param mobile 用户手机号
	 * @return 今天请求发送短信的次数
	 */
	public long getMobileCount(String mobile){
		String sql = "SELECT count(id) FROM " + getNowTableName() + " WHERE mobile=? AND send_time >= CURDATE()";
		System.out.println("getMobileCount, mobile:" + mobile);
		return (long) (Math.random()*6);
	}

	/**
	 * 获得指定ip今天请求发送短信的次数
	 *
	 * @param ip 用户ip
	 * @return 今天请求发送短信的次数
	 */
	public long getIPCount(String ip){
		String sql = "SELECT count(id) FROM " + getNowTableName() + " WHERE ip=? AND send_time >= CURDATE()";
		System.out.println("getIPCount, IP: " + ip);
		return (long) (Math.random()*6);
	}

	/**
	 * 获得现在使用的表的名字
	 */
	private String getNowTableName() {
		return getTableName(0);
	}

	private DateFormat dateFormat = new SimpleDateFormat("yyyy_MM");

	/**
	 * 获得相对现在偏移monthExcursion月的表名
	 *
	 * @param monthExcursion 偏移的月数
	 * @return 对应月的表名
	 */
	private String getTableName(int monthExcursion) {
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.MONTH, monthExcursion);
		Date date = calendar.getTime();
		return "sms_" + dateFormat.format(date);
	}

}
