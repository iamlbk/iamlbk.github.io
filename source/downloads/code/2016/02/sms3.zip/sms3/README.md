﻿本程序是博客:《[发送短信--限制日发送次数][blog url]》的示例程序.
博客地址: http://www.iamlbk.com/blog/20160219/sms-java-code-3/

cn文件夹下是使用`wsimport -keep http://106.ihuyi.cn/webservice/sms.php?WSDL`下载下来的客户端代码. 可能已经过时无法使用.
git文件夹下的是示例程序.

如果需要使用本程序，请注明出处.

[blog url]: http://www.iamlbk.com/blog/20160219/sms-java-code-3/
