/*
 * Copyright 2015 LBK
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package git.lbk.sms;

import cn.ihuyi._106.SmsSoap;
import cn.ihuyi._106.SubmitResult;

public class IhuyiSmsImpl implements Sms {

	private String account;
	private String password;

	public void setAccount(String account) {
		this.account = account;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * 向mobile发送message消息
	 * @param mobile 手机号
	 * @param message 短信内容
	 * @return 成功返回-1, 否则返回其他值
	 */
	@Override
	public int sendMessage(String mobile, String message) {
		cn.ihuyi._106.Sms factory = new cn.ihuyi._106.Sms();
        SmsSoap smsSoap = factory.getSmsSoap();
        SubmitResult submit = smsSoap.submit(account, password, mobile, message);
        int code = submit.getCode();
        if(code == 2){
            return -1;
        }
        System.out.println("发送短信失败, code:" + code);
        return code;
	}

}
