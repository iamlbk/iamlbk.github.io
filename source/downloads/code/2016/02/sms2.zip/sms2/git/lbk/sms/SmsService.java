/*
 * Copyright 2015 LBK
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package git.lbk.sms;

import java.util.List;
import java.util.Properties;

/**
 * 最终提供发送短信的类.
 * 可以使用一个模板发送短信
 */
public class SmsService{

	private Sms sms;
	private List<SmsFilter> filters;
	private Properties template;
	
	public SmsService() {
		template = new Properties();
		template.put("register", "验证码为:{captcha}");
	}

	public void setSms(Sms sms) {
		this.sms = sms;
	}

	public void setFilters(List<SmsFilter> filters) {
		this.filters = filters;
	}
	/**
	 * 发送验证码
	 *
	 * @param smsEntity 发送短信的基本数据
	 * @return 如果提交成功, 返回0. 否则返回其他值.
	 */
	public int sendCaptcha(SmsEntity smsEntity){
		for(SmsFilter filter : filters) {
			if(!filter.filter(smsEntity)){
				return 1;
			}
		}
		if(SmsEntity.REGISTER_TYPE.equals(smsEntity.getType())) {
			sendRegisterSms(smsEntity);
		}
		else{
			return 2;
		}
		return 0;
	}

	/**
	 * 发送注册验证码
	 *
	 * @param smsEntity 发送短信的基本数据
	 */
	private void sendRegisterSms(SmsEntity smsEntity) {
		sms.sendMessage(smsEntity.getMobile(),
				template.getProperty("register").replace("{captcha}", smsEntity.getCaptcha()));
	}

}
