
package cn.ihuyi._106;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>anonymous complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="GetKeFuResult" type="{http://106.ihuyi.cn/}GetKeFuResult" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "getKeFuResult"
})
@XmlRootElement(name = "GetKeFuResponse")
public class GetKeFuResponse {

    @XmlElement(name = "GetKeFuResult")
    protected GetKeFuResult getKeFuResult;

    /**
     * ��ȡgetKeFuResult���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link GetKeFuResult }
     *     
     */
    public GetKeFuResult getGetKeFuResult() {
        return getKeFuResult;
    }

    /**
     * ����getKeFuResult���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link GetKeFuResult }
     *     
     */
    public void setGetKeFuResult(GetKeFuResult value) {
        this.getKeFuResult = value;
    }

}
