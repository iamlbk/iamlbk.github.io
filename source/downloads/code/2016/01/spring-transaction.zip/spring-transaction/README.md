﻿本程序是博客:《[spring事务管理失效的原因][why-spring-transaction-invalid]》的示例程序.
博客地址: http://www.iamlbk.com/blog/20160111/why-spring-transaction-invalid/
如果需要使用本程序， 请注明出处.

**在运行程序之前, 记得修改数据库连接属性, 并导入数据库脚本**. 配置文件在src/main/resources/applicationContext.xml, 数据库脚本为user.sql

该程序没有main方法, 使用Junit运行. 测试类在src/test/java/git/lbk/service/SpringTransactionTest.java.
该测试类中共有六个测试方法, 其中只有`testSaveError`和`testSaveUsers`可以正常运行, 其他的测试方法均会失败

[why-spring-transaction-invalid]: http://www.iamlbk.com/blog/20160111/why-spring-transaction-invalid/
