﻿/*
 * Copyright 2016 LBK
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package git.lbk.service;

import git.lbk.dao.UserDao;
import git.lbk.entity.User;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:applicationContext.xml")
public class SpringTransactionTest {

	@Autowired
	private UserService userService;
	
	@Autowired
	private UserDao userDao;

	private User user1, user2;

	@Before
	public void setUp() {
		user1 = new User(0, "aa", 20);
		user2 = new User(0, "bb", 25);
	}

	/**
	 * 检验user1是否插入成功, 并尝试删除数据. 如果没有插入, 则报错, 并退出.
	 */
	private void validateInsertSuccess() {
		User user = userService.getUserByName(user1.getName());
		userService.deleteByName(user1.getName()); // 删除用户数据
		assertNotEquals("插入失败!", -1, user.getId().intValue());
	}

	/**
	 * 检验user1是否插入失败. 如果插入成功, 则删除数据, 并报错.
	 */
	private void validateInsertFail() {
		User user = userService.getUserByName(user1.getName());
		userService.deleteByName(user1.getName()); // 删除用户数据
		assertEquals("插入成功, 事务没有生效!" + user, -1, user.getId().intValue());
	}

	@Test
	public void testSaveUsers() {
		try {
			userService.save(user1);
		}
		catch (ArithmeticException e) {
			// 除零异常, 直接忽略
		}
		validateInsertSuccess(); // 应该插入成功
	}

	@Test
	public void testSaveError() {
		try {
			userService.saveError(user1, user2);
		}
		catch (ArithmeticException e) {
			// 除零异常, 直接忽略
		}
		validateInsertFail(); // 应该插入失败
	}

	@Test
	public void testSaveErrorFinal() {
		try {
			userService.saveErrorFinal(user1, user2);
		}
		catch (ArithmeticException e) {
			// 除零异常, 直接忽略
		}
		validateInsertFail(); // 我们假设有事务支持, user1添加失败
	}

	@Test
	public void testSaveErrorStatic() {
		try {
			UserService.saveErrorStatic(userDao, user1, user2);
		}
		catch (ArithmeticException e) {
			// 除零异常, 直接忽略
		}
		validateInsertFail(); // 我们假设有事务支持, user1添加失败
	}
	
	@Test
	public void testSaveByCallMethod() {
		try {
			userService.saveByCallMethod(user1, user2);
		}
		catch (ArithmeticException e) {
			// 除零异常, 直接忽略
		}
		validateInsertFail(); // 我们假设有事务支持, user1添加失败
	}
	
	@Test
	public void testSaveByThread() throws InterruptedException{
		try {
			userService.saveByThread(user1, user2);
		}
		catch (ArithmeticException e) {
			// 除零异常, 直接忽略
		}
		Thread.sleep(2000);	// 等待创建的线程保存数据
		System.out.println("验证事务是否生效");
		validateInsertFail(); // 我们假设有事务支持, user1添加失败
	}
}
