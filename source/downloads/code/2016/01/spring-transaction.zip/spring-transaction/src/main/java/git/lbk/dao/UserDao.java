/*
 * Copyright 2016 LBK
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package git.lbk.dao;

import git.lbk.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;

@Repository
public class UserDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	/**
	 * 保存用户信息
	 */
	public void save(User user) {
		String sql = "INSERT INTO user(name, age) VALUES(?, ?)";
		jdbcTemplate.update(sql, user.getName(), user.getAge());
	}

	/**
	 * 根据用户名获取User对象
	 * 
	 * @param name
	 *            用户名
	 * @return User对象. 如果查询出数据则返回相应的数据, 否则user的id为-1
	 */
	public User getUserByName(String name) {
		String sqlStr = " SELECT id, name, age " + " FROM user WHERE name =? ";
		final User user = new User(-1, name, -1);
		jdbcTemplate.query(sqlStr, new Object[] { name }, new RowCallbackHandler() {
			public void processRow(ResultSet rs) throws SQLException {
				user.setId(rs.getInt("id"));
				user.setAge(rs.getInt("age"));
			}
		});
		return user;
	}

	/**
	 * 删除指定用户名的用户信息
	 */
	public void deleteByName(String name) {
		String sql = "DELETE FROM user WHERE name = ?";
		jdbcTemplate.update(sql, name);
	}

}
