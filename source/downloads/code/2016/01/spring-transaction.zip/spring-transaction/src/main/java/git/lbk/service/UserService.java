/*
 * Copyright 2016 LBK
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package git.lbk.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import git.lbk.dao.UserDao;
import git.lbk.entity.User;

@Service
public class UserService {
	
	@Autowired
	private UserDao userDao;

	public UserDao getUserDao() {
		return userDao;
	}
	
	/**
	 * 根据用户名获取User对象
	 * 
	 * @return 如果存在该用户, 返回用户信息, 否则id=-1
	 */
	@Transactional
	public User getUserByName(String name) {
		return userDao.getUserByName(name);
	}

	/**
	 * 删除指定用户名的用户信息
	 */
	@Transactional
	public void deleteByName(String name) {
		userDao.deleteByName(name);
	}

	/**
	 * 保存user对象. 确保正常情况下可以保存数据
	 */
	@Transactional
	public void save(User user1) {
		userDao.save(user1);
	}

	/**
	 * 保存两个user对象, 中间产生异常. 验证spring的事务是否可以正常工作
	 */
	@Transactional
	public void saveError(User user1, User user2) {
		userDao.save(user1);
		System.out.println(10 / 0); // 引发异常
		userDao.save(user2);
	}

	/**
	 * 保存两个user对象. 添加了spring事务注解
	 */
	@Transactional
	public final void saveErrorFinal(User user1, User user2) {
		UserDao userDao = getUserDao();	// 此处需要使用getUserDao方法. 不能直接使用userDao
		userDao.save(user1);
		System.out.println(10 / 0); // 引发异常
		userDao.save(user2);
	}

	/**
	 * 静态方法. 添加了spring事务注解
	 */
	@Transactional
	public static void saveErrorStatic(UserDao userDao, User user1, User user2) {
		userDao.save(user1);
		System.out.println(10 / 0); // 引发异常
		userDao.save(user2);
	}

	/**
	 * 私有方法保存方法. 添加了spring事务注解
	 */
	@Transactional
	private void saveErrorPrivate(User user1, User user2) {
		userDao.save(user1);
		System.out.println(10 / 0); // 引发异常
		userDao.save(user2);
	}

	/**
	 * 通过{@link #saveError(User, User)}保存数据, 该方法本身并没有添加事务注解. 而是通过
	 * {@link #saveError(User, User)}方法使用事务
	 */
	public void saveByCallMethod(User user1, User user2) {
		//saveErrorPrivate(user1, user2);
		saveError(user1, user2);
	}

	/**
	 * 通过创建一个新的线程, 调用{@link #saveError(User, User)}方法来保存用户, 该方法和
	 * {@link #saveError(User, User)}方法都添加了事务注解
	 */
	@Transactional
	public void saveByThread(User user1, User user2) {
		new Thread(() -> {
			try {
				Thread.sleep(1000); //耗时操作
				saveError(user1, user2);
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			System.out.println("保存完成");
		}).start();
	}

}
