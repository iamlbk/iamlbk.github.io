﻿本程序是博客:《[java中String+String和String+char的区别][string-add-string-and-string-add-char]》的示例程序.
博客地址: http://www.iamlbk.com/blog/20160123/string-add-string-and-string-add-char/
如果需要使用本程序， 请注明出处.

[string-add-string-and-string-add-char]: http://www.iamlbk.com/blog/20160123/string-add-string-and-string-add-char/
